<?php /* #?ini charset="utf-8"? 
# search for template operators in groupdocsannotation 
[TemplateSettings]
ExtensionAutoloadPath[]=groupdocsannotation
*/ ?>