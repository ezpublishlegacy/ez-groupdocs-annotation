<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsannotation

#[StylesheetSettings]
#BackendCSSFileList[]=gdannotation_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdannotation.js
*/ ?>